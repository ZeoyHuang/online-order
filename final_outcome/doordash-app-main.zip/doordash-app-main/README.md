# How to run the application

first run `npm ci` to install all the packages

then run `npm run start` to start the application
